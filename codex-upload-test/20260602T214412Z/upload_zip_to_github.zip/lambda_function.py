import json
import base64
import requests
import os
import boto3
from datetime import datetime, timezone
from botocore.exceptions import ClientError

s3 = boto3.client('s3')
secretsmanager = boto3.client('secretsmanager')
_github_token_cache = None


def lambda_handler(event, context):
    event = event or {}

    # 環境変数から設定を取得
    GITHUB_TOKEN = get_github_token()
    REPO_OWNER = os.getenv('REPO_OWNER')
    REPO_NAME = os.getenv('REPO_NAME')
    S3_BUCKET = os.getenv('S3_BUCKET')

    # GitHub API用ヘッダー（先に定義）
    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    # ステップファンクションからファイル名を受け取る
    FILE_NAME = event.get('output_key') or ''
    FILE_NAME = FILE_NAME.strip()
    if FILE_NAME.startswith('/'):
        FILE_NAME = FILE_NAME[1:]

    OUTPUT_NAME = event.get('output_path') or ''
    OUTPUT_NAME = OUTPUT_NAME.strip()
    if OUTPUT_NAME.startswith('/'):
        OUTPUT_NAME = OUTPUT_NAME[1:]

    # 必要な設定が存在するか確認
    if not all([GITHUB_TOKEN, REPO_OWNER, REPO_NAME, FILE_NAME, OUTPUT_NAME, S3_BUCKET]):
        raise ValueError('必要なパラメータが正しく設定されていません')

    # GitHub APIエンドポイント（ルートディレクトリ直下に保存）
    GITHUB_API_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{OUTPUT_NAME}"

    # S3 からファイルを取得
    try:
        s3_object = s3.get_object(Bucket=S3_BUCKET, Key=FILE_NAME)
        file_content = s3_object['Body'].read()
        encoded_content = base64.b64encode(file_content).decode()
    except Exception as e:
        print("ERROR - Failed to fetch file from S3:", str(e))
        raise

    # 既存ファイルのSHAを取得
    response = requests.get(GITHUB_API_URL, headers=headers)
    print("GET Response:", response.status_code)

    if response.status_code == 200:
        sha = response.json().get("sha")
    elif response.status_code == 404:
        sha = None  # 新規ファイルとしてアップロード
    else:
        raise RuntimeError(f"GitHub file metadata fetch failed: {response.status_code} {response.text}")

    # GitHub APIへのPUTリクエスト
    current_time = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
    data = {
        "message": f"Automated update at {current_time}",
        "content": encoded_content
    }
    if sha:
        data["sha"] = sha

    upload_response = requests.put(GITHUB_API_URL, headers=headers, data=json.dumps(data))

    # 結果の確認
    if upload_response.status_code in [200, 201]:
        return {
            'statusCode': 200,
            'body': json.dumps('File uploaded successfully!'),
            'yyyymm': event.get('yyyymm'),
            'output_key': FILE_NAME,
            'output_path': OUTPUT_NAME
        }
    else:
        print("PUT Response:", upload_response.status_code, upload_response.text)
        raise RuntimeError(f"GitHub upload failed: {upload_response.status_code} {upload_response.text}")


def get_github_token():
    global _github_token_cache
    if _github_token_cache:
        return _github_token_cache

    secret_id = os.getenv('GITHUB_TOKEN_SECRET_ID')
    if secret_id:
        try:
            secret = secretsmanager.get_secret_value(SecretId=secret_id)
        except ClientError as error:
            token = os.getenv('GITHUB_TOKEN')
            if token:
                print(f"WARNING - Failed to read GitHub token secret; using GITHUB_TOKEN fallback: {error.response['Error']['Code']}")
                _github_token_cache = token
                return _github_token_cache
            raise
        else:
            secret_string = secret.get('SecretString')
            if not secret_string:
                raise ValueError('GitHub token secret does not contain SecretString')

            try:
                secret_value = json.loads(secret_string)
            except json.JSONDecodeError:
                token = secret_string
            else:
                token = secret_value.get('GITHUB_TOKEN') if isinstance(secret_value, dict) else None

            if not token:
                raise ValueError('GitHub token secret does not contain GITHUB_TOKEN')

            _github_token_cache = token
            return _github_token_cache

    token = os.getenv('GITHUB_TOKEN')
    if token:
        _github_token_cache = token
        return _github_token_cache

    raise ValueError('GITHUB_TOKEN_SECRET_ID or GITHUB_TOKEN must be set')
